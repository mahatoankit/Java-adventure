The file phone-data.txt contains data from https://pricespy.co.uk/ (accessed 26/04/2018) with one phone per line, in the following format:

`model screenSize batteryCapacity`

The model names have underscores instead of spaces. 
